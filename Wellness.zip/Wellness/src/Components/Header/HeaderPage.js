import React, { Component } from "react";
import {
    Container,
    WebsiteTitle,
    WebsiteDescription,
    MyPicture,
    MyPic,
    MyLogo,
    WebsiteNamesContainer,
    SideMenu,
    Text,
    LogoContainer
} from "./styledComponents.js";



import logo from '../../Assets/logo.jpg';


import menu from '../../Assets/sidemenubarIcon.jpeg';
class HeaderPage extends Component {
  render() {
    return (
      <div>
         <Container>
           <SideMenu>
           <MyPicture>
              <MyLogo src={menu} />
              </MyPicture>
{/* <Text>Open</Text> */}
           </SideMenu>



           <LogoContainer>
          {/* <MyPicture>
              <MyLogo src={logo} />
              </MyPicture> */}

<WebsiteNamesContainer>
<WebsiteTitle>
            WCAM
          </WebsiteTitle>
          <WebsiteDescription>
            Wellness Centre Appointment Management
          </WebsiteDescription>
</WebsiteNamesContainer>
</LogoContainer>
        </Container>
        
      </div>
    );
  }
}
export default HeaderPage;