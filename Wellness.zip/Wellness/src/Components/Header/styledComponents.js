import styled from "@emotion/styled";

export const Container = styled.div`
  background-color: #5b2f91;
  padding: 10px;
   display:flex;
   flex-direction:row;
  justify-content:flex-start;
   align-items:center;

   
`;

export const LogoContainer = styled.div`

   display:flex;
   flex-direction:row;
   justify-content:flex-end;
   align-items:center;

   
`;



export const SideMenu = styled.div`
 display:flex;
 align-items:center;

   
`;
export const Text = styled.div`
color: #5d56bb;
font-size: 21px;
text-align: left;
color: #fff;
font-weight: 700;
margin-left:10px;

   
`;

export const WebsiteTitle = styled.div`
  color: #5d56bb;
  font-size: 21px;
  text-align: left;
  color: #fff;
  font-weight: 700;
  align-items:center;
  margin-left:15px;
`;

export const WebsiteDescription = styled.div`
  color: #5d56bb;
  text-align: left;
  color: #fff;
  font-size: 10px;
  font-weight: 700;
  align-items:center;
  margin-left:15px;
`;

export const WebsiteNamesContainer = styled.div`
  display:flex;
  flex-direction:column;
`;




export const MyPicture = styled.div`
  

  //   width: 450px;
  // display: flex;
  // align-items: center;
  // justify-content: center;
`;

export const MyPic = styled.img`
  width: 200px;
  height: 200px;
  // object-fit: contain;
  // margin: 20px;
 border-radius: 50%;
`;

export const MyLogo = styled.img`
width:40px;
height:40px;
border-radius:50%;
align-items:center;
`;
