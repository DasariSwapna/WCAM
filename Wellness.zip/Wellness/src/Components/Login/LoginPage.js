import React, { Component } from "react";
import {
  Container,
  FormHeading,
  Inputbox,
  Label,
  Form,
  FormInnerContainer,
  Submit,
  InnerContainer,
  Button

} from "./styledComponents.js";

class LoginPage extends Component {
  render() {
    return (
      <div>
        <Container>
          <InnerContainer>

       
          <FormHeading>Wellness Center Login</FormHeading>
          <Button>
            Guest login
          </Button>
          </InnerContainer>
          <Form>


            <FormInnerContainer>

            
            <Label>
           Enter 919 number:
              
            </Label>{" "}
           
            <Inputbox type="text" name="name" />
            </FormInnerContainer>

            <FormInnerContainer>
            <Label>Enter Password:</Label>
            <Inputbox type="password" name="name" />
            </FormInnerContainer>

          

        

            <Submit type="submit" value="Submit" />
          </Form>
        </Container>
      </div>
    );
  }
}
export default LoginPage;
