import styled from "@emotion/styled";

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  margin: 40px;
  width: 90%;
`;

export const FormHeading = styled.div`
  font-size: 30px;
  text-align: left;
  color: #0a0a0a;
  font-weight: 700;
  // align-items: center;
  margin-bottom: 20px;
`;

export const Inputbox = styled.input`
  width: 100%;
  border: 0;
  border-top: 1px solid #9a9fa8;
  border-bottom: 1px solid #9a9fa8;
  background: #fbfbfb;
  box-shadow: none;
  height: 30px;
  padding-left: 32px;
  margin-bottom: 0;
  padding-bottom: 0;
`;

export const Label = styled.label`
  color: #0a0a0a;
  font-size: 15px;
  font-weight: 400;
  float: left;
`;
export const Form = styled.label`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
`;

export const FormInnerContainer = styled.label`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 30px;
`;
export const Submit = styled.input`
  
width: 100%;
border: 0;
border-top: 1px solid #9a9fa8;
border-bottom: 1px solid #9a9fa8;
box-shadow: none;
height: 50px;
padding-left: 32px;
margin-bottom: 0;
padding-bottom: 0;
color: white;
background-color: #5b2f91;
`;

export const InputboxArea = styled.input`
  width: 100%;
  border: 0;
  border-top: 1px solid #9a9fa8;
  border-bottom: 1px solid #9a9fa8;
  background: #fbfbfb;
  box-shadow: none;
  height: 60px;
  padding-left: 32px;
  margin-bottom: 0;
  padding-bottom: 0;
`;


export const Button = styled.button`
  
 width: 200px;
 display:flex;
flex-direaction:row;
 align-items:center;
 justify-content:center;
border: 0;
border-top: 1px solid #9a9fa8;
border-bottom: 1px solid #9a9fa8;
box-shadow: none;
height: 50px;
padding-left: 32px;
margin-bottom: 0;
padding-bottom: 0;
color: white;
background-color: #5b2f91;
`;
export const InnerContainer = styled.div`
display:flex;
flex-direaction:row;

justify-content:space-between;



`;
