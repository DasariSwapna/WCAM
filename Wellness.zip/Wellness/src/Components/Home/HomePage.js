import React, { Component } from "react";


import HeaderPage from "../Header/HeaderPage.js";
import {
  Container,
  TitleContainer,
  Title,
  Description,
  ImageContainer,
  MyLogo,
  ContainerforButton,
  Button
  
  
} from "./styledComponents.js";

import homepicture from "../../Assets/logo.jpg";




  

class HomePage extends Component {
  render() {
    return (
      <div>
      
        <HeaderPage />
  

        <Container>
          <TitleContainer>
            <Title>Campus Wellness Services</Title>
            <Description>
              Wellness Services offers counseling, wellness education and
              prevention, and clinic services. Focuses on the eight dimensions
              of wellness.
            </Description>
          </TitleContainer>
          <ImageContainer>
            <MyLogo src={homepicture} />
          </ImageContainer>
        </Container>
        <p>
          Advertisements ....
        </p>
      <ContainerforButton>


<button type="button">Click Me!</button>
<button type="button">Click Me!</button>
<button type="button">Click Me!</button>
</ContainerforButton>
      </div>
    );
  }
}
export default HomePage;

