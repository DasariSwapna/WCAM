import styled from "@emotion/styled";

export const Container = styled.div`

  
   margin-bottom:40px;
   display:flex;
   flex-direction:row;
   justify-content:flex-start;
   align-items:center;

   
`;

export const TitleContainer = styled.div`

`;

export const ContainerforButton = styled.div`
display:flex;
flex-direction:row;
justify-content:space-around;
align-items:center;
`;

export const Link = styled.div`

`;

export const Button = styled.button`
background-color:blue;

`;


export const Title = styled.div`
  color: #241a49;
  font-size: 45px;
  text-align: left;
  font-weight: 700;
  align-items:center;
  margin-left:15px;
`;


export const Description = styled.div`
  
color: #241a49;
  font-size: 15px;
  text-align: left;
  font-size: 21px;
  font-weight: 700;
  align-items:center;
  margin-left:15px;
  margin-top:20px;


`;
export const ImageContainer = styled.div`

`;
export const MyLogo = styled.img`
width:600px;
height:500px;
align-items:center;
`;
